# SDKv2Sequence
Template to program sequences in Java with the SDK
It is based on the grafcet model  https://lab4sys.com/en/grafcet-the-basics/
