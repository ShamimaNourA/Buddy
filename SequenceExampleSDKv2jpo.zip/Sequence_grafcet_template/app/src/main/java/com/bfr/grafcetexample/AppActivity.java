package com.bfr.grafcetexample;

import com.bfr.buddysdk.BuddyApplication;

public class AppActivity extends BuddyApplication {
    @Override
    public void onCreate() {
        super.onCreate();
    }
}
